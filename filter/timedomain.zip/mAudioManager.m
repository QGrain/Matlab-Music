function haudio = mAudioManager(argin)
    %argin{1} = AudioData
    %argin{2} = Fs
    %argin{3} = mode  ('start', 'pause', 'resume', 'stop', 'filter')
    %argin{4} = filterParameter (todo)
    
        
end